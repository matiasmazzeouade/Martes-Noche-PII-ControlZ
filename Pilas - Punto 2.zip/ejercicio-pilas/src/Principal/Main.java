package Principal;

import Implementacion.Ejercicio2;


public class Main {
    public static void main(String[] args) {

        Ejercicio2.Estrategia_3_Undo undo = new Ejercicio2.Estrategia_3_Undo();
        undo.InicializarPila();

        // Estado inicial del código
        String codigo = "int a = 5;\nint b = 10;";
        System.out.println("Estado inicial:\n" + codigo);

        // ===== CAMBIO 1 =====
        undo.Apilar(codigo); // guardo estado antes del cambio
        codigo = "int a = 5;";
        System.out.println("\nDespués de borrar una línea:\n" + codigo);

        // ===== CAMBIO 2 =====
        undo.Apilar(codigo);
        codigo = "int a = 20;";
        System.out.println("\nDespués de modificar valor:\n" + codigo);

        // ===== CTRL + Z =====
        if (!undo.PilaVacia()) {
            codigo = undo.Tope();
            undo.Desapilar();
        }
        System.out.println("\nCtrl+Z (undo 1):\n" + codigo);

        // ===== CTRL + Z =====
        if (!undo.PilaVacia()) {
            codigo = undo.Tope();
            undo.Desapilar();
        }
        System.out.println("\nCtrl+Z (undo 2):\n" + codigo);
    }
}