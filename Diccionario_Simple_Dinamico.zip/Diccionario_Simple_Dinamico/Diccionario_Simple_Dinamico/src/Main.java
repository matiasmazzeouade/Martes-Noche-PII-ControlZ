import Implementacion.DiccionarioSimpleDinamico;
import Interface.DiccionarioSimpleTDA;

public class Main {
    public static void main(String[] args) {

        DiccionarioSimpleTDA dic = new DiccionarioSimpleDinamico();
        dic.InicializarDiccionario();

        // Clave = ID jugador
        // Valor = puntaje máximo

        dic.Agregar(1, 1500);
        dic.Agregar(2, 2300);
        dic.Agregar(3, 1800);

        // El jugador 2 mejora su puntaje
        dic.Agregar(2, 2500);

        System.out.println("Jugadores en el torneo:");

        int[] claves = dic.Claves();
        for (int i = 0; i < claves.length; i++) {
            System.out.println("Jugador ID: " + claves[i]);
        }

        // Eliminamos un jugador
        dic.Eliminar(1);

        System.out.println("\nJugadores luego de eliminar al ID 1:");

        int[] claves2 = dic.Claves();
        for (int i = 0; i < claves2.length; i++) {
            System.out.println("Jugador ID: " + claves2[i]);
        }
    }
}
