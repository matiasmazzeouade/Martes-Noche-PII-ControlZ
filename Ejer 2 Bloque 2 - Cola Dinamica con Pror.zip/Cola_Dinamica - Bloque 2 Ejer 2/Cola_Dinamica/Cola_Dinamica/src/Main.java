import Implementacion.ColaDinamica;
import Interface.ColaTDA;

public class Main {
    public static void main(String[] args) {
        ColaTDA cola = new ColaDinamica();
        cola.InicializarCola();

        cola.Acolar(4);
        cola.Acolar(1);
        cola.Acolar(7);
        cola.Acolar(3);
        cola.Acolar(9);

        System.out.println("Orden de salida según prioridad:");

        while (!cola.ColaVacia()) {
            System.out.println(cola.Primero());
            cola.Desacolar();
        }
    }
}