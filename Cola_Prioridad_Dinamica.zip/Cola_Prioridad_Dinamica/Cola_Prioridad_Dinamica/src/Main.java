import Implementacion.ColaPrioridadDinamica;
import Interface.ColaPrioridadTDA;

public class Main {
    public static void main(String[] args) {
        ColaPrioridadTDA guardia = new ColaPrioridadDinamica();

        guardia.InicializarColaPrioridad();

        System.out.println("¿La guardia está vacía?: " + guardia.ColaVacia());

        // Acolar pacientes: (numeroPaciente, prioridad)
        // Mayor número = mayor urgencia
        guardia.AcolarPrioridad(101, 1);   // resfriado
        guardia.AcolarPrioridad(102, 100);  // infarto
        guardia.AcolarPrioridad(103, 50);   // fractura

        System.out.println("\nPrimer paciente a atender: " + guardia.Primero());
        System.out.println("Prioridad: " + guardia.Prioridad());

        while (!guardia.ColaVacia()) {
            System.out.println("\nSe atiende al paciente: " + guardia.Primero());
            System.out.println("Con prioridad: " + guardia.Prioridad());
            guardia.Desacolar();
        }

        System.out.println("\n¿La guardia está   vacía?: " + guardia.ColaVacia());
    }
}
