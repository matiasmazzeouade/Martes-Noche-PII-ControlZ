package ABB;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class IndiceDePalabras {

    // Nodo específico para palabras (clave = String, ordenado alfabéticamente).
    private static class NodoPalabra {
        String palabra;
        int apariciones;
        NodoPalabra izquierdo;
        NodoPalabra derecho;

        NodoPalabra(String palabra) {
            this.palabra = palabra;
            this.apariciones = 1;
        }
    }

    private NodoPalabra raiz;

    /** Agrega una aparición de la palabra (la crea o incrementa su contador). */
    public void agregar(String palabra) {
        raiz = agregarRecursivo(raiz, palabra);
    }

    private NodoPalabra agregarRecursivo(NodoPalabra actual, String palabra) {
        if (actual == null) {
            return new NodoPalabra(palabra);
        }
        int cmp = palabra.compareTo(actual.palabra);
        if (cmp < 0) {
            actual.izquierdo = agregarRecursivo(actual.izquierdo, palabra);
        } else if (cmp > 0) {
            actual.derecho = agregarRecursivo(actual.derecho, palabra);
        } else {
            actual.apariciones++; // ya existía -> sumo una aparición
        }
        return actual;
    }

    /** Muestra el índice ordenado alfabéticamente (recorrido inorden). */
    public void mostrar() {
        mostrarRecursivo(raiz);
    }

    private void mostrarRecursivo(NodoPalabra actual) {
        if (actual == null) {
            return;
        }
        mostrarRecursivo(actual.izquierdo);
        System.out.println(actual.palabra + " -> " + actual.apariciones);
        mostrarRecursivo(actual.derecho);
    }

    /** Procesa un texto: lo separa en palabras y las indexa. */
    public void indexarTexto(String texto) {
        // Paso a minúsculas y reemplazo todo lo que no sea letra/número por espacio.
        // (Incluye acentos del español). Los arrays no están prohibidos.
        String limpio = texto.toLowerCase();
        String[] palabras = limpio.split("[^a-záéíóúñü0-9]+");
        for (int i = 0; i < palabras.length; i++) {
            if (!palabras[i].isEmpty()) {
                agregar(palabras[i]);
            }
        }
    }

    public static void main(String[] args) {
        // Ejemplo del enunciado
        IndiceDePalabras ejemplo = new IndiceDePalabras();
        ejemplo.indexarTexto("casa árbol casa río árbol árbol");
        System.out.println("--- Ejemplo del enunciado ---");
        ejemplo.mostrar();

        // Índice sobre Texto.txt (si está disponible)
        try {
            String contenido = new String(
                Files.readAllBytes(Paths.get("ABB/Texto.txt")),
                StandardCharsets.UTF_8
            );
            IndiceDePalabras indice = new IndiceDePalabras();
            indice.indexarTexto(contenido);
            System.out.println("\n--- Índice de Texto.txt ---");
            indice.mostrar();
        } catch (IOException e) {
            System.out.println("\n(No se pudo leer ABB/Texto.txt: " + e.getMessage() + ")");
        }
    }
}
