import Implementacion.Estrategia_1;
import Interfaces.PilaTDA;

public class Main {
    public static void main(String[] args) {

        PilaTDA historial = new Estrategia_1();
        historial.InicializarPila();
        String paginaActual;
        paginaActual = "fi.uba.ar";
        System.out.println("Página actual: " + paginaActual);
        historial.Apilar(paginaActual);
        System.out.println("Se apila: " + paginaActual);
        paginaActual = "campus.utn.edu.ar";
        System.out.println("Página actual: " + paginaActual);
        historial.Apilar(paginaActual);
        System.out.println("Se apila: " + paginaActual);
        paginaActual = "stackoverflow.com";
        System.out.println("Página actual: " + paginaActual);

        System.out.println("Usuario presiona Atrás");

        if (!historial.PilaVacia()) {
            System.out.println("Tope antes de desapilar: " + historial.Tope());
            paginaActual = historial.Tope();
            historial.Desapilar();
            System.out.println("Se desapila y vuelve a: " + paginaActual);
        }
    }
}

