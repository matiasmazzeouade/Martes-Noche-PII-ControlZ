//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import Implementacion.Estrategia_1;
import Interfaz.PilaTDA;

public class Main {
    public static void main(String[] args) {
        PilaTDA pila = new Estrategia_1();
        pila.InicializarPila();

        String palabra = "ALGORITMOS";
        System.out.println("Palabra original: " + palabra);

        // MOMENTO 1: APILAR (Carga de datos)
        // Recorremos la palabra y metemos cada letra en la pila
        for (int i = 0; i < palabra.length(); i++) {
            char letra = palabra.charAt(i);
            pila.Apilar((int) letra); // Casteamos char a int para que entre en tu Pila
        }

        System.out.print("Palabra invertida: ");

        // MOMENTO 2: DESAPILAR (Extracción)
        // Mientras la pila tenga algo, sacamos el tope y lo mostramos
        while (!pila.PilaVacia()) {
            int codigoAscii = pila.Tope();
            System.out.print((char) codigoAscii); // Convertimos de nuevo a letra
            pila.Desapilar();
        }
        System.out.println();
    }
}