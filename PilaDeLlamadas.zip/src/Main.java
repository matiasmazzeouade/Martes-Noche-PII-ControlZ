//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import Implementacion.Estrategia_1;
import Interfaz.PilaTDA;

public class Main {
    public static void main(String[] args) {
        PilaTDA callStack = new Estrategia_1();
        callStack.InicializarPila();

        System.out.println("--- Simulando Pila de Llamadas ---");

        // 1. Se ejecuta Main (lo representamos con un ID o código)
        // Digamos que Main es 100, CalcularPromedio es 200 y Sumar es 300
        callStack.Apilar(100);
        System.out.println("Ejecutando Main... (Tope: " + callStack.Tope() + ")");

        // 2. Main llama a CalcularPromedio
        callStack.Apilar(200);
        System.out.println("Main llamó a CalcularPromedio... (Tope: " + callStack.Tope() + ")");

        // 3. CalcularPromedio llama a Sumar
        callStack.Apilar(300);
        System.out.println("CalcularPromedio llamó a Sumar... (Tope: " + callStack.Tope() + ")");

        System.out.println("\n>>> RESPUESTA: En el momento de la suma, el tope es: " + callStack.Tope());

        // 4. Termina Sumar (Desapilar)
        callStack.Desapilar();
        System.out.println("\nTerminó Sumar, volviendo a: " + callStack.Tope());

        // 5. Termina CalcularPromedio (Desapilar)
        callStack.Desapilar();
        System.out.println("Terminó CalcularPromedio, volviendo a: " + callStack.Tope());
    }
}