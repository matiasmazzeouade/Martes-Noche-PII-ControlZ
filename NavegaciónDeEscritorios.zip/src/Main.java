//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import Implementacion.Estrategia_1;
import Interfaz.PilaTDA;

public class Main {
    public static void main(String[] args) {
        PilaTDA historial = new Estrategia_1();
        historial.InicializarPila();

        System.out.println("--- Navegación de Directorios ---");

        // Supongamos: C:/ es 1, Usuarios es 2, Documentos es 3

        // 1. Estamos en C:/ y entramos a Usuarios
        historial.Apilar(1);
        System.out.println("Entraste a 'Usuarios'. (Para volver, el sistema mira el tope: " + historial.Tope() + ")");

        // 2. De Usuarios entramos a Documentos
        historial.Apilar(2);
        System.out.println("Entraste a 'Documentos'. (Para volver, el sistema mira el tope: " + historial.Tope() + ")");

        System.out.println("\n[!] El usuario apretó 'Subir un nivel' (flecha arriba)");

        // 3. Subir nivel: Desapilamos y vemos dónde quedamos
        if (!historial.PilaVacia()) {
            int carpetaAnterior = historial.Tope();
            historial.Desapilar();
            System.out.println("Volviendo a la carpeta con código: " + carpetaAnterior);
        }

        if (!historial.PilaVacia()) {
            System.out.println("Si volvés a subir, irás a: " + historial.Tope());
        }
    }
}