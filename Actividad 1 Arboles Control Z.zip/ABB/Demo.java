package ABB;
public class Demo {
    public static void main(String[] args) {
        ABBEnterosImpl a = new ABBEnterosImpl();
        int[] vals = {8,3,10,1,6,14,4,7,13};
        for (int v : vals) a.agregar(v);

        System.out.print("InOrden  : "); a.mostrarInOrden();
        System.out.print("PreOrden : "); a.mostrarPreOrden();
        System.out.print("PostOrden: "); a.mostrarPostOrden();
        System.out.println("altura=" + a.altura() + " cantidad=" + a.cantidad()
            + " min=" + a.minimo() + " max=" + a.maximo());
        System.out.println("enRango(1,14) = " + a.enRango(1,14));
        System.out.println("enRango(2,14) = " + a.enRango(2,14));

        ConjuntoABB c1 = new ConjuntoABB();
        ConjuntoABB c2 = new ConjuntoABB();
        for (int v : new int[]{1,2,3,4,5}) c1.agregar(v);
        for (int v : new int[]{3,4,5,6,7}) c2.agregar(v);
        System.out.print("Interseccion {1..5} y {3..7}: ");
        c1.interseccion(c2).mostrar();
        System.out.println("cantidad c1=" + c1.cantidad() + " elegir=" + c1.elegir());
    }
}
