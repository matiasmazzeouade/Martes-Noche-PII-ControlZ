package Implementacion;

import Interface.ColaTDA;

public class ColaDinamica implements ColaTDA {

    private Node frente; // apunta al primer nodo de la cola (el que se despacola primero)
    private Node fondo;  // apunta al último nodo de la cola (donde se acola)

    @Override
    public void InicializarCola() {
        frente = null;
        fondo = null;
    }

    @Override
    public void Acolar(int x) {
        Node nuevo = new Node(x, null);

        if (ColaVacia()) {
            frente = nuevo;
            fondo = nuevo;
            return;
        }

        if (x > frente.getData()) {
            nuevo.setNext(frente);
            frente = nuevo;
            return;
        }

        Node actual = frente;

        while (actual.getNext() != null && actual.getNext().getData() >= x) {
            actual = actual.getNext();
        }

        nuevo.setNext(actual.getNext());
        actual.setNext(nuevo);

        if (nuevo.getNext() == null) {
            fondo = nuevo;
        }
    }

    @Override
    public void Desacolar() {
        if (!ColaVacia()) {
            // Avanzamos frente al siguiente nodo, descartando el nodo actual.
            frente = frente.getNext();
            if (frente == null) {
                fondo = null;
            }
        }
    }

    @Override
    public int Primero() {
        return frente.getData();
    }

    @Override
    public boolean ColaVacia() {
        return frente == null;
    }
}