import Implementacion.PilaDinamica;
import Interfaces.PilaTDA;

public class Main {
    public static void main(String[] args) {
        // Usamos la implementación dinámica con Nodos
        PilaTDA callStack = new PilaDinamica();
        callStack.InicializarPila();

        System.out.println("--- SIMULACIÓN DINÁMICA: CALL STACK ---");

        // Representamos las funciones con IDs:
        // 1 = main(), 2 = calcularPromedio(), 3 = sumar()

        // 1. Se inicia el programa
        callStack.Apilar(1);
        System.out.println("Se apila main() -> Tope actual: " + callStack.Tope());

        // 2. main() llama a calcularPromedio()
        callStack.Apilar(2);
        System.out.println("main llama a calcularPromedio() -> Tope actual: " + callStack.Tope());

        // 3. calcularPromedio() llama a sumar()
        callStack.Apilar(3);
        System.out.println("calcularPromedio llama a sumar() -> Tope actual: " + callStack.Tope());

        System.out.println("\n>>> RESPUESTA: En el momento de la suma, el proceso en el tope es: " + callStack.Tope());

        // 4. Termina la ejecución y la pila se vacía (LIFO)
        System.out.println("\n--- Finalizando ejecuciones ---");

        while (!callStack.PilaVacia()) {
            System.out.println("Terminando proceso: " + callStack.Tope());
            callStack.Desapilar();
            if (!callStack.PilaVacia()) {
                System.out.println("Volviendo al control de: " + callStack.Tope());
            } else {
                System.out.println("Pila de llamadas vacía. Programa finalizado.");
            }
        }
    }
}