package ABB;

public class ConjuntoABB {

    private final ABBEnterosImpl arbol = new ABBEnterosImpl();

    public void agregar(int valor) {
        arbol.agregar(valor);
    }

    public boolean eliminar(int valor) {
        return arbol.eliminar(valor);
    }

    public boolean contiene(int valor) {
        return arbol.contiene(valor);
    }

    public int cantidad() {
        return arbol.cantidad();
    }

    /** Devuelve un elemento cualquiera del conjunto (usamos el menor). */
    public int elegir() {
        if (cantidad() == 0) {
            throw new IllegalStateException("El conjunto está vacío");
        }
        return arbol.minimo();
    }

    /** Devuelve un nuevo conjunto con los elementos comunes a ambos. */
    public ConjuntoABB interseccion(ConjuntoABB otro) {
        ConjuntoABB resultado = new ConjuntoABB();
        llenarInterseccion(arbol.getRaiz(), otro, resultado);
        return resultado;
    }

    // Recorro este conjunto; si el otro también lo tiene, va al resultado.
    private void llenarInterseccion(Nodo actual, ConjuntoABB otro, ConjuntoABB resultado) {
        if (actual == null) {
            return;
        }
        if (otro.contiene(actual.valor)) {
            resultado.agregar(actual.valor);
        }
        llenarInterseccion(actual.izquierdo, otro, resultado);
        llenarInterseccion(actual.derecho, otro, resultado);
    }

    public void mostrar() {
        arbol.mostrarInOrden();
    }
}
