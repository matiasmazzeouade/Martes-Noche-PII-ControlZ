import Interfaces.PilaTDA;

public class Main {
    public static void main(String[] args) {
        // La expresión que nos dio el profe
        String expresion = "((a+b)*c)";

        PilaTDA pila = new Implementacion.Estrategia_1();
        pila.InicializarPila();

        boolean error = false;

        for (int i = 0; i < expresion.length(); i++) {
            char caracter = expresion.charAt(i);

            if (caracter == '(') {
                // APILAR: Encontramos uno que abre, lo guardamos
                pila.Apilar(1); // Usamos el 1 como "marca" de que hay algo abierto
                System.out.println("Momento Apilar: Se encontró '('");
                //Cada vez que el puntero del compilador detecta el símbolo (, la Pila aumenta su cantidad.
            }
            else if (caracter == ')') {
                // COMPARAR para DESAPILAR
                if (!pila.PilaVacia()) {
                    pila.Desapilar();
                    System.out.println("Momento Desapilar: Se encontró ')' y se cerró una pareja.");
                } else {
                    System.out.println("Error: Se cerró un paréntesis que nunca se abrió.");
                    error = true;
                    break;
                }
            }
        }

        // Al final, la pila DEBE estar vacía
        if (!error && pila.PilaVacia()) {
            System.out.println("\nResultado: ¡La expresión está balanceada!");
        } else {
            System.out.println("\nResultado: Error de balanceo.");
        }
    }
}