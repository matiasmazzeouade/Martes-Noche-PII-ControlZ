package ABB;

public class ABBEnterosImpl implements ABBEnteros {
    private Nodo raiz;

    
    // Ejer1 - Inserción recursiva
    // Complejidad peor caso: O(n) -> árbol degenerado (datos ya ordenados,
    // queda como una lista enlazada). Caso promedio (árbol balanceado): O(log n).
    
    @Override
    public void agregar(int valor) {
        raiz = agregarRecursivo(raiz, valor);
    }

    private Nodo agregarRecursivo(Nodo actual, int valor) {
        // Caso base: llegué a un lugar vacío -> creo el nodo.
        if (actual == null) {
            return new Nodo(valor);
        }
        if (valor < actual.valor) {
            actual.izquierdo = agregarRecursivo(actual.izquierdo, valor);
        } else if (valor > actual.valor) {
            actual.derecho = agregarRecursivo(actual.derecho, valor);
        }
        // Si valor == actual.valor -> duplicado: no hago nada.
        return actual;
    }

    // Ejer2 - Inserción iterativa (con bucles, sin recursión)
    public void agregarIterativo(int valor) {
        if (raiz == null) {
            raiz = new Nodo(valor);
            return;
        }
        Nodo actual = raiz;
        while (true) {
            if (valor == actual.valor) {
                return;
            } else if (valor < actual.valor) {
                if (actual.izquierdo == null) {
                    actual.izquierdo = new Nodo(valor);
                    return;
                }
                actual = actual.izquierdo;
            } else { // valor > actual.valor
                if (actual.derecho == null) {
                    actual.derecho = new Nodo(valor);
                    return;
                }
                actual = actual.derecho;
            }
        }
    }

    // Ejer3 - Búsqueda
    // Complejidad peor caso: O(n) (árbol degenerado). Promedio: O(log n).
    @Override
    public boolean contiene(int valor) {
        return contieneRecursivo(raiz, valor);
    }

    private boolean contieneRecursivo(Nodo actual, int valor) {
        if (actual == null) {
            return false;
        }
        if (valor == actual.valor) {
            return true;
        }
        if (valor < actual.valor) {
            return contieneRecursivo(actual.izquierdo, valor);
        }
        return contieneRecursivo(actual.derecho, valor);
    }

    // Ejer6 - Eliminación
    @Override
    public boolean eliminar(int valor) {
        if (!contiene(valor)) {
            return false;
        }
        raiz = eliminarRecursivo(raiz, valor);
        return true;
    }

    private Nodo eliminarRecursivo(Nodo actual, int valor) {
        if (actual == null) {
            return null;
        }
        if (valor < actual.valor) {
            actual.izquierdo = eliminarRecursivo(actual.izquierdo, valor);
        } else if (valor > actual.valor) {
            actual.derecho = eliminarRecursivo(actual.derecho, valor);
        } else {
            // Caso 1: hoja -> lo elimino directamente
            if (actual.esHoja()) {
                return null;
            }
            // Caso 2: un solo hijo -> "subo" ese hijo
            if (actual.izquierdo == null) {
                return actual.derecho;
            }
            if (actual.derecho == null) {
                return actual.izquierdo;
            }
            // Caso 3: dos hijos -> uso el sucesor (mínimo del subárbol derecho)
            Nodo sucesor = minimoRecursivo(actual.derecho);
            actual.valor = sucesor.valor;
            actual.derecho = eliminarRecursivo(actual.derecho, sucesor.valor);
        }
        return actual;
    }

    #Ejer 4 - Estadísticas del árbol
    
    @Override
    public int cantidad() {
        return cantidadRecursivo(raiz);
    }

    private int cantidadRecursivo(Nodo actual) {
        if (actual == null) {
            return 0;
        }
        return 1 + cantidadRecursivo(actual.izquierdo) + cantidadRecursivo(actual.derecho);
    }

    @Override
    public int altura() {
        return alturaRecursivo(raiz);
    }

    private int alturaRecursivo(Nodo actual) {
        if (actual == null) {
            return 0; // árbol vacío -> 0; solo raíz -> 1
        }
        int altIzq = alturaRecursivo(actual.izquierdo);
        int altDer = alturaRecursivo(actual.derecho);
        return 1 + Math.max(altIzq, altDer);
    }

    @Override
    public int minimo() {
        if (raiz == null) {
            throw new IllegalStateException("El árbol está vacío");
        }
        return minimoRecursivo(raiz).valor;
    }

    private Nodo minimoRecursivo(Nodo actual) {
        // El mínimo es el nodo más a la izquierda.
        if (actual.izquierdo == null) {
            return actual;
        }
        return minimoRecursivo(actual.izquierdo);
    }

    @Override
    public int maximo() {
        if (raiz == null) {
            throw new IllegalStateException("El árbol está vacío");
        }
        return maximoRecursivo(raiz).valor;
    }

    private Nodo maximoRecursivo(Nodo actual) {
        // El máximo es el nodo más a la derecha.
        if (actual.derecho == null) {
            return actual;
        }
        return maximoRecursivo(actual.derecho);
    }

    // Ejer5 - Recorridos. Complejidad: O(n) (se visita cada nodo 1 vez).
    @Override
    public void mostrarInOrden() {
        mostrarInOrdenRecursivo(raiz);
        System.out.println();
    }

    private void mostrarInOrdenRecursivo(Nodo actual) {
        if (actual == null) {
            return;
        }
        mostrarInOrdenRecursivo(actual.izquierdo);
        System.out.print(actual.valor + " ");
        mostrarInOrdenRecursivo(actual.derecho);
    }

    @Override
    public void mostrarPreOrden() {
        mostrarPreOrdenRecursivo(raiz);
        System.out.println();
    }

    private void mostrarPreOrdenRecursivo(Nodo actual) {
        if (actual == null) {
            return;
        }
        System.out.print(actual.valor + " ");
        mostrarPreOrdenRecursivo(actual.izquierdo);
        mostrarPreOrdenRecursivo(actual.derecho);
    }

    @Override
    public void mostrarPostOrden() {
        mostrarPostOrdenRecursivo(raiz);
        System.out.println();
    }

    private void mostrarPostOrdenRecursivo(Nodo actual) {
        if (actual == null) {
            return;
        }
        mostrarPostOrdenRecursivo(actual.izquierdo);
        mostrarPostOrdenRecursivo(actual.derecho);
        System.out.print(actual.valor + " ");
    }

    // Ejer7 - Validación de rango.
    // Devuelve true si TODOS los valores del árbol están dentro de
    // [desde, hasta] (bordes incluidos).
    public boolean enRango(int desde, int hasta) {
        return enRangoRecursivo(raiz, desde, hasta);
    }

    private boolean enRangoRecursivo(Nodo actual, int desde, int hasta) {
        if (actual == null) {
            return true;
        }
        if (actual.valor < desde || actual.valor > hasta) {
            return false;
        }
        return enRangoRecursivo(actual.izquierdo, desde, hasta)
            && enRangoRecursivo(actual.derecho, desde, hasta);
    }

    
    Nodo getRaiz() {
        return raiz;
    }
}
