package Interfaces;

public interface PilaStringTDA {
    void InicializarPila();
    void Apilar(String x);
    void Desapilar();
    String Tope();
    boolean PilaVacia();
}